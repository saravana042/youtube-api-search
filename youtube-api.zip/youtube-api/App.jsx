import _ from 'lodash';
import React from 'react';
import ReactDOM from 'react-dom';
import YTSearch from 'youtube-api-search'
import Search_bar from './components/Search_bar.js';
import Video_list from './components/Video_list.js';
import Video_detail from './components/Video_detail.js';

const API_KEY = 'AIzaSyBjFOqfHDIOPrxznWnDuu8S7WOeJcdWDgA';


class App extends React.Component {

	constructor(props){
		super(props);
		this.state = {
			videos:[],
			selectedVideo:null
		};

		this.videoSearch('cricket');
	}
	videoSearch(term) {
		YTSearch({key:API_KEY, term:term}, (videos) => {
			this.setState({
				videos:videos,
				selectedVideo:videos[0]
			});			
		});
	}
   render() {
   		const videoSearch = _.debounce((term) =>{this.videoSearch(term)}, 2000);
      return (
         <div>
   
            <Search_bar onSearchTermChange={videoSearch} />
            <Video_detail video={this.state.selectedVideo} />
            <Video_list
            	onVideoSelect = {selectedVideo => this.setState({selectedVideo})}
             	videos={this.state.videos} />
         </div>
      );
   }

}

export default App;