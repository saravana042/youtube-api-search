import React from 'react';
import Video_list_item from './Video_list_item.js';

class Video_list extends React.Component {
   render(props) {

	   	const videos = this.props.videos;
	   	const videoItem = this.props.videos.map((video) => {
			return <Video_list_item
				onVideoSelect = {this.props.onVideoSelect}
				key={video.etag}
				video={video} 
			/>
	   	});
	   	
		return (
			<div className="video-list col-md-8">
			<ul>
			{videoItem}
			</ul>
			</div>
		);
   }
}




export default Video_list;