import React, {Component} from 'react';

class Search_bar extends Component {
	constructor(props){
		super(props);
		this.state = {term:''}
	}
   render() {
      return (
         <div>
           <input value={this.state.term} onChange={(event) => this.onInputchange(event.target.value)} />
           {this.state.term}
         </div>
      );
   }
   onInputchange(term){
		this.setState({term});
		this.props.onSearchTermChange(term);
	}
}

export default Search_bar;